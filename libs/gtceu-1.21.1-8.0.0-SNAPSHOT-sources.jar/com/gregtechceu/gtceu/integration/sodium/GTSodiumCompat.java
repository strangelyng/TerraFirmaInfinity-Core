package com.gregtechceu.gtceu.integration.sodium;

import com.gregtechceu.gtceu.client.renderer.CustomChunkRenderPass;
import com.gregtechceu.gtceu.client.renderer.CustomChunkRenderPassRegistry;
import com.gregtechceu.gtceu.client.renderer.GTRenderTypes;
import com.gregtechceu.gtceu.client.util.TextureMetadataHelper;
import com.gregtechceu.gtceu.config.ConfigHolder;
import com.gregtechceu.gtceu.utils.TriState;
import net.caffeinemc.mods.sodium.client.render.chunk.terrain.TerrainRenderPass;
import net.caffeinemc.mods.sodium.client.render.chunk.terrain.material.Material;
import net.caffeinemc.mods.sodium.client.render.chunk.terrain.material.parameters.AlphaCutoffParameter;
import net.caffeinemc.mods.sodium.client.render.frapi.mesh.MutableQuadViewImpl;
import net.caffeinemc.mods.sodium.client.render.texture.SpriteFinderCache;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadView;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import org.jetbrains.annotations.Nullable;
import java.util.Arrays;
import java.util.IdentityHashMap;
import java.util.Map;

public final class GTSodiumCompat {
    private static volatile TerrainRenderPass[] cachedDefaultPasses;
    private static volatile TerrainRenderPass[] cachedCombinedPasses;
    private static final java.util.concurrent.atomic.AtomicReference<Object> customRenderPasses = new java.util.concurrent.atomic.AtomicReference<Object>();
    private static final java.util.concurrent.atomic.AtomicReference<Object> customMaterials = new java.util.concurrent.atomic.AtomicReference<Object>();

    private static Map<RenderType, TerrainRenderPass> createCustomRenderPasses() {
        Map<RenderType, TerrainRenderPass> passes = new IdentityHashMap<>();
        for (var pass : CustomChunkRenderPassRegistry.activePasses()) {
            passes.put(pass.renderType(), new TerrainRenderPass(pass.renderType(), false, true));
        }
        return passes;
    }

    private static Map<RenderType, Material> createCustomMaterials() {
        Map<RenderType, Material> materials = new IdentityHashMap<>();
        for (var pass : CustomChunkRenderPassRegistry.activePasses()) {
            materials.put(pass.renderType(), new Material(getCustomRenderPasses().get(pass.renderType()), getAlphaCutoff(pass.alphaCutoff()), pass.mipped()));
        }
        return materials;
    }

    private static AlphaCutoffParameter getAlphaCutoff(CustomChunkRenderPass.AlphaCutoff alphaCutoff) {
        return switch (alphaCutoff) {
            case ZERO -> AlphaCutoffParameter.ZERO;
            case ONE_TENTH -> AlphaCutoffParameter.ONE_TENTH;
            case HALF -> AlphaCutoffParameter.HALF;
            case ONE -> AlphaCutoffParameter.ONE;
        };
    }

    @Nullable
    public static TerrainRenderPass getCustomRenderPass(RenderType renderType) {
        return getCustomRenderPasses().get(renderType);
    }

    @Nullable
    public static Material getCustomMaterial(RenderType renderType) {
        return getCustomMaterials().get(renderType);
    }

    // Extend each backend-owned view instead of mutating Sodium's shared static pass array.
    public static TerrainRenderPass[] includeCustomRenderPasses(TerrainRenderPass[] defaultPasses) {
        TerrainRenderPass[] combinedPasses = cachedCombinedPasses;
        if (defaultPasses == cachedDefaultPasses && combinedPasses != null) {
            return combinedPasses;
        }
        synchronized (GTSodiumCompat.class) {
            if (defaultPasses != cachedDefaultPasses || cachedCombinedPasses == null) {
                cachedCombinedPasses = combineRenderPasses(defaultPasses);
                cachedDefaultPasses = defaultPasses;
            }
            return cachedCombinedPasses;
        }
    }

    private static TerrainRenderPass[] combineRenderPasses(TerrainRenderPass[] defaultPasses) {
        TerrainRenderPass[] customPasses = CustomChunkRenderPassRegistry.activePasses().stream().map(pass -> getCustomRenderPass(pass.renderType())).filter(pass -> Arrays.stream(defaultPasses).noneMatch(existing -> existing == pass)).toArray(TerrainRenderPass[]::new);
        if (customPasses.length == 0) return defaultPasses;
        TerrainRenderPass[] passes = Arrays.copyOf(defaultPasses, defaultPasses.length + customPasses.length);
        System.arraycopy(customPasses, 0, passes, defaultPasses.length, customPasses.length);
        return passes;
    }

    public static TerrainRenderPass getBloomRenderPass() {
        return getCustomRenderPass(GTRenderTypes.bloom());
    }

    public static Material getBloomMaterial() {
        return getCustomMaterial(GTRenderTypes.bloom());
    }

    public static TerrainRenderPass getFaceLayerRenderPass() {
        return getCustomRenderPass(GTRenderTypes.faceLayer());
    }

    public static Material getFaceLayerMaterial() {
        return getCustomMaterial(GTRenderTypes.faceLayer());
    }

    public static boolean quadHasBloom(MutableQuadViewImpl quad, int[] ambientPackedLights) {
        TextureAtlasSprite sprite = quad.sprite(SpriteFinderCache.forBlockAtlas());
        var metadata = TextureMetadataHelper.getMetadata(sprite);
        if (metadata.isPresent()) {
            TriState bloomValue = metadata.get().bloom();
            if (bloomValue == TriState.TRUE) return true;
             else 
            // Explicitly disable bloom if it's set to FALSE in the metadata
            if (bloomValue == TriState.FALSE) return false;
        }
        // fall through to emissivity config check if default
        if (ConfigHolder.INSTANCE.client.bloom.emissiveTexturesHaveBloom) {
            return isEmissive(quad, ambientPackedLights);
        }
        return false;
    }

    public static boolean isEmissive(QuadView quad, int[] ambientPackedLights) {
        for (int i = 0; i < 4; i++) {
            int quadLight = quad.lightmap(i);
            int qBlock = LightTexture.block(quadLight);
            int qSky = LightTexture.sky(quadLight);
            int ambientLight = ambientPackedLights[i];
            int aBlock = LightTexture.block(ambientLight);
            int aSky = LightTexture.sky(ambientLight);
            if (qBlock > aBlock || qSky > aSky) {
                return true;
            }
        }
        return false;
    }

    private GTSodiumCompat() {
    }

    public static Map<RenderType, TerrainRenderPass> getCustomRenderPasses() {
        Object $value = GTSodiumCompat.customRenderPasses.get();
        if ($value == null) {
            synchronized (GTSodiumCompat.customRenderPasses) {
                $value = GTSodiumCompat.customRenderPasses.get();
                if ($value == null) {
                    final Map<RenderType, TerrainRenderPass> actualValue = createCustomRenderPasses();
                    $value = actualValue == null ? GTSodiumCompat.customRenderPasses : actualValue;
                    GTSodiumCompat.customRenderPasses.set($value);
                }
            }
        }
        return (Map<RenderType, TerrainRenderPass>) ($value == GTSodiumCompat.customRenderPasses ? null : $value);
    }

    public static Map<RenderType, Material> getCustomMaterials() {
        Object $value = GTSodiumCompat.customMaterials.get();
        if ($value == null) {
            synchronized (GTSodiumCompat.customMaterials) {
                $value = GTSodiumCompat.customMaterials.get();
                if ($value == null) {
                    final Map<RenderType, Material> actualValue = createCustomMaterials();
                    $value = actualValue == null ? GTSodiumCompat.customMaterials : actualValue;
                    GTSodiumCompat.customMaterials.set($value);
                }
            }
        }
        return (Map<RenderType, Material>) ($value == GTSodiumCompat.customMaterials ? null : $value);
    }
}
