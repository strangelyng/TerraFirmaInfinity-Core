package com.gregtechceu.gtceu.integration.jade.provider;

import com.gregtechceu.gtceu.GTCEu;
import com.gregtechceu.gtceu.common.machine.trait.hazard.EnvironmentalHazardCleanerTrait;

import net.minecraft.nbt.FloatTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.entity.BlockEntity;

import snownee.jade.api.BlockAccessor;
import snownee.jade.api.ITooltip;
import snownee.jade.api.config.IPluginConfig;

public class HazardCleanerBlockProvider extends MachineTraitProvider<EnvironmentalHazardCleanerTrait, FloatTag> {

    public HazardCleanerBlockProvider() {
        super(GTCEu.id("hazard_cleaner_provider"), EnvironmentalHazardCleanerTrait.class);
    }

    @Override
    protected FloatTag write(EnvironmentalHazardCleanerTrait capability) {
        return FloatTag.valueOf(capability.getRemovedLastSecond());
    }

    @Override
    protected void addTooltip(FloatTag capData, ITooltip tooltip, Player player, BlockAccessor block,
                              BlockEntity blockEntity, IPluginConfig config) {
        float cleaned = capData.getAsFloat();
        if (cleaned > 0) {
            tooltip.add(Component.translatable("gtceu.jade.cleaned_this_second", cleaned));
        }
    }
}
