package com.gregtechceu.gtceu.integration.ae2.machine;

import com.gregtechceu.gtceu.api.blockentity.BlockEntityCreationInfo;
import com.gregtechceu.gtceu.api.capability.recipe.IO;
import com.gregtechceu.gtceu.api.machine.trait.notifiable.NotifiableItemStackHandler;
import com.gregtechceu.gtceu.api.sync_system.annotations.SaveField;
import com.gregtechceu.gtceu.api.transfer.item.CustomItemStackHandler;
import com.gregtechceu.gtceu.integration.ae2.gui.AEKeyStorageSyncHandler;
import com.gregtechceu.gtceu.integration.ae2.gui.AEStackDisplayWidget;
import com.gregtechceu.gtceu.integration.ae2.gui.ScrollPreservingGrid;
import com.gregtechceu.gtceu.integration.ae2.utils.KeyStorage;
import com.gregtechceu.gtceu.utils.FormattingUtil;
import net.minecraft.MethodsReturnNonnullByDefault;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import appeng.api.config.Actionable;
import appeng.api.stacks.AEItemKey;
import appeng.api.stacks.AEKey;
import brachy.modularui.api.drawable.Text;
import brachy.modularui.factory.PosGuiData;
import brachy.modularui.screen.UISettings;
import brachy.modularui.value.sync.BooleanSyncValue;
import brachy.modularui.value.sync.DynamicLinkedSyncHandler;
import brachy.modularui.value.sync.PanelSyncManager;
import brachy.modularui.widget.ParentWidget;
import brachy.modularui.widget.scroll.VerticalScrollData;
import brachy.modularui.widgets.DynamicSyncedWidget;
import brachy.modularui.widgets.layout.Flow;
import it.unimi.dsi.fastutil.objects.Object2LongMap;
import org.jetbrains.annotations.Nullable;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import javax.annotation.ParametersAreNonnullByDefault;

/**
 * The Output Bus that can directly send its contents to ME storage network.
 */
@MethodsReturnNonnullByDefault
@ParametersAreNonnullByDefault
public class MEOutputBusPartMachine extends MEBusPartMachine {
    @SaveField
    private KeyStorage internalBuffer; // Do not use KeyCounter, use our simple implementation

    public MEOutputBusPartMachine(BlockEntityCreationInfo info) {
        super(info, IO.OUT, new InaccessibleInfiniteHandler());
        internalBuffer = ((InaccessibleInfiniteHandler) getInventory()).getInternalBuffer();
    }

    /////////////////////////////////
    // ***** Machine LifeCycle ****//
    /////////////////////////////////
    @Override
    public void onMachineDestroyed() {
        var grid = getMainNode().getGrid();
        if (grid != null && !internalBuffer.isEmpty()) {
            for (var entry : internalBuffer) {
                grid.getStorageService().getInventory().insert(entry.getKey(), entry.getLongValue(), Actionable.MODULATE, actionSource);
            }
        }
    }

    /////////////////////////////////
    // ********** Sync ME *********//
    /////////////////////////////////
    @Override
    protected boolean shouldSubscribe() {
        return super.shouldSubscribe() && !internalBuffer.storage.isEmpty();
    }

    @Override
    public void autoIO() {
        if (!this.shouldSyncME()) return;
        if (this.updateMEStatus()) {
            var grid = getMainNode().getGrid();
            if (grid != null && !internalBuffer.isEmpty()) {
                internalBuffer.insertInventory(grid.getStorageService().getInventory(), actionSource);
            }
            this.updateInventorySubscription();
        }
    }

    ///////////////////////////////
    // ********** GUI ***********//
    ///////////////////////////////
    @Override
    public void buildMainUI(ParentWidget<?> mainWidget, PosGuiData guiData, PanelSyncManager syncManager, UISettings settings) {
        BooleanSyncValue isOnlineValue = new BooleanSyncValue(this::isOnline, this::setOnline);
        syncManager.syncValue("is_online", isOnlineValue);
        var flow = Flow.col().coverChildren();
        flow.child(Text.dynamic(() -> isOnlineValue.getBoolValue() ? Component.translatable("gtceu.gui.me_network.online") : Component.translatable("gtceu.gui.me_network.offline")).asWidget().marginTop(2).marginBottom(4));
        var storageSyncHandler = new AEKeyStorageSyncHandler(internalBuffer);
        syncManager.syncValue("ae_output_display", storageSyncHandler);
        int[] savedScroll = {0};
        var dynamicHandler = new DynamicLinkedSyncHandler<>(storageSyncHandler).widgetProvider((sm, value) -> {
            var col = Flow.col().leftRel(0.5F).coverChildrenHeight();
            var list = value.getValue();
            if (list.isEmpty()) return col.child(Text.lang("gtceu.gui.waiting_list_empty").asWidget());
            col.child(Text.lang("gtceu.gui.waiting_list").asWidget().margin(0, 2));
            col.child(new ScrollPreservingGrid(savedScroll).size(167, 67).scrollable(new VerticalScrollData()).gridOfSizeWidth(list.size(), 1, (x, y, index) -> {
                var widget = new AEStackDisplayWidget(list, index);
                var row = Flow.row().coverChildrenHeight().child(widget);
                var entry = list.get(index);
                return row.child(Text.comp(Component.literal(FormattingUtil.formatNumbers(entry.amount()) + "x").append(CommonComponents.SPACE).append(entry.what().getDisplayName())).asWidget().width(140).marginLeft(3));
            }));
            return col;
        });
        flow.child(new DynamicSyncedWidget<>().syncHandler(dynamicHandler).size(167, 80));
        mainWidget.child(flow);
    }

    // for Jade Provider
    public Iterator<Object2LongMap.Entry<AEKey>> storageIterator() {
        return internalBuffer.iterator();
    }


    private static class InaccessibleInfiniteHandler extends NotifiableItemStackHandler {
        private KeyStorage internalBuffer;

        public InaccessibleInfiniteHandler() {
            super(1, IO.OUT, IO.NONE, ItemStackHandlerDelegate::new);
            internalBuffer = new KeyStorage();
            ((ItemStackHandlerDelegate) storage).setKeyStorage(internalBuffer);
            internalBuffer.setOnContentsChanged(this::onContentsChanged);
        }

        @Override
        public List<Object> getContents() {
            return Collections.emptyList();
        }

        @Override
        public double getTotalContentAmount() {
            return 0;
        }

        @Override
        public boolean isEmpty() {
            return true;
        }

        public KeyStorage getInternalBuffer() {
            return this.internalBuffer;
        }
    }


    private static class ItemStackHandlerDelegate extends CustomItemStackHandler {
        @Nullable
        KeyStorage keyStorage = null;

        // Necessary for InaccessibleInfiniteHandler
        public ItemStackHandlerDelegate(Integer integer) {
            super();
        }

        @Override
        public int getSlots() {
            return Short.MAX_VALUE;
        }

        @Override
        public int getSlotLimit(int slot) {
            return Integer.MAX_VALUE;
        }

        @Override
        public ItemStack getStackInSlot(int slot) {
            return ItemStack.EMPTY;
        }

        @Override
        public void setStackInSlot(int slot, ItemStack stack) {
            // NO-OP
        }

        @Override
        public ItemStack insertItem(int slot, ItemStack stack, boolean simulate) {
            if (keyStorage == null) return stack;
            var key = AEItemKey.of(stack);
            int count = stack.getCount();
            long oldValue = keyStorage.storage.getOrDefault(key, 0);
            long changeValue = Math.min(Long.MAX_VALUE - oldValue, count);
            if (changeValue > 0) {
                if (!simulate) {
                    keyStorage.storage.put(key, oldValue + changeValue);
                    keyStorage.onChanged();
                }
                return stack.copyWithCount((int) (count - changeValue));
            } else {
                return stack;
            }
        }

        @Override
        public ItemStack extractItem(int slot, int amount, boolean simulate) {
            return ItemStack.EMPTY;
        }

        public ItemStackHandlerDelegate() {
        }

        @Nullable
        public KeyStorage getKeyStorage() {
            return this.keyStorage;
        }

        public void setKeyStorage(@Nullable final KeyStorage keyStorage) {
            this.keyStorage = keyStorage;
        }
    }
}
