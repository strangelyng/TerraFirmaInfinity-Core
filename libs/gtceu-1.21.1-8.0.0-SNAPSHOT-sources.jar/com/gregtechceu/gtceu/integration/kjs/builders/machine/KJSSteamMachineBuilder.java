package com.gregtechceu.gtceu.integration.kjs.builders.machine;

import com.gregtechceu.gtceu.GTCEu;
import com.gregtechceu.gtceu.api.blockentity.BlockEntityCreationInfo;
import com.gregtechceu.gtceu.api.machine.MachineDefinition;
import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gregtechceu.gtceu.api.machine.property.GTMachineModelProperties;
import com.gregtechceu.gtceu.api.machine.steam.SimpleSteamMachine;
import com.gregtechceu.gtceu.api.multiblock.util.RelativeDirection;
import com.gregtechceu.gtceu.api.registry.registrate.GTRegistrate;
import com.gregtechceu.gtceu.api.registry.registrate.builder.MachineBuilder;
import com.gregtechceu.gtceu.api.registry.registrate.entry.MachineEntry;
import com.gregtechceu.gtceu.utils.FormattingUtil;
import net.minecraft.resources.ResourceLocation;
import dev.latvian.mods.kubejs.client.LangKubeEvent;
import dev.latvian.mods.kubejs.generator.KubeAssetGenerator;
import dev.latvian.mods.kubejs.registry.BuilderBase;
import org.jetbrains.annotations.Nullable;
import java.util.Objects;

public class KJSSteamMachineBuilder extends BuilderBase<MachineDefinition> implements IMachineBuilderKJS {
    public transient boolean hasLowPressure = true;
    public transient boolean hasHighPressure = true;
    public transient SteamCreationFunction machine = SimpleSteamMachine::new;
    public transient SteamDefinitionFunction definition = (isHP, def) -> def.tier(isHP ? 1 : 0);
    @Nullable
    private MachineBuilder<MachineDefinition, ?, ?> lowPressureBuilder = null;
    @Nullable
    private MachineBuilder<MachineDefinition, ?, ?> highPressureBuilder = null;
    @Nullable
    private MachineEntry<MachineDefinition> lpObject = null;
    @Nullable
    private MachineEntry<MachineDefinition> hpObject = null;

    public KJSSteamMachineBuilder(ResourceLocation id) {
        super(id);
        this.dummyBuilder = true;
    }

    @Override
    @Nullable
    public MachineDefinition createObject() {
        if (hasLowPressure) {
            this.lowPressureBuilder = GTRegistrate.createIgnoringListenerErrors(this.id.getNamespace()).machine(String.format("lp_%s", this.id.getPath()), holder -> machine.create(holder, false)).langValue("Low Pressure " + FormattingUtil.toEnglishName(this.id.getPath())).tier(0).recipeModifier(SimpleSteamMachine::recipeModifier).modelProperty(GTMachineModelProperties.VENT_DIRECTION, RelativeDirection.BACK).workableSteamHullModel(false, id.withPrefix("block/machines/"));
            definition.apply(false, lowPressureBuilder);
            this.lpObject = lowPressureBuilder.register();
        }
        if (hasHighPressure) {
            this.highPressureBuilder = GTRegistrate.createIgnoringListenerErrors(this.id.getNamespace()).machine(String.format("hp_%s", this.id.getPath()), holder -> machine.create(holder, true)).langValue("High Pressure " + FormattingUtil.toEnglishName(this.id.getPath())).tier(1).recipeModifier(SimpleSteamMachine::recipeModifier).modelProperty(GTMachineModelProperties.VENT_DIRECTION, RelativeDirection.BACK).workableSteamHullModel(true, id.withPrefix("block/machines/"));
            definition.apply(true, highPressureBuilder);
            this.hpObject = highPressureBuilder.register();
        }
        return null;
    }

    @Override
    public void generateMachineModels() {
        generateMachineModel(lowPressureBuilder, Objects.requireNonNull(lpObject).value());
        generateMachineModel(highPressureBuilder, Objects.requireNonNull(hpObject).value());
    }

    @Override
    public void generateAssets(KubeAssetGenerator generator) {
        if (this.lowPressureBuilder != null) {
            generator.itemModel(id, gen -> gen.parent(id.withPrefix("block/machine/")));
        }
        if (this.highPressureBuilder != null) {
            generator.itemModel(id, gen -> gen.parent(id.withPrefix("block/machine/")));
        }
    }

    @Override
    public String getTranslationKeyGroup() {
        return "block";
    }

    @SuppressWarnings("DataFlowIssue")
    @Override
    public void generateLang(LangKubeEvent lang) {
        if (lpObject != null) {
            lang.add(GTCEu.MOD_ID, lpObject.value().getDescriptionId(), lpObject.value().getLangValue());
        }
        if (hpObject != null) {
            lang.add(GTCEu.MOD_ID, hpObject.value().getDescriptionId(), hpObject.value().getLangValue());
        }
    }


    @FunctionalInterface
    public interface SteamCreationFunction {
        MetaMachine create(BlockEntityCreationInfo info, boolean isHighPressure);
    }


    @FunctionalInterface
    public interface SteamDefinitionFunction {
        void apply(boolean isHighPressure, MachineBuilder<?, ?, ?> builder);
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public KJSSteamMachineBuilder hasLowPressure(final boolean hasLowPressure) {
        this.hasLowPressure = hasLowPressure;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public KJSSteamMachineBuilder hasHighPressure(final boolean hasHighPressure) {
        this.hasHighPressure = hasHighPressure;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public KJSSteamMachineBuilder machine(final SteamCreationFunction machine) {
        this.machine = machine;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public KJSSteamMachineBuilder definition(final SteamDefinitionFunction definition) {
        this.definition = definition;
        return this;
    }
}
