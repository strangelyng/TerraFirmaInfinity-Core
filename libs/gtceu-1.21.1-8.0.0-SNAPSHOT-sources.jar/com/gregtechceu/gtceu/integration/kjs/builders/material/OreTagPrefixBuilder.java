package com.gregtechceu.gtceu.integration.kjs.builders.material;

import com.gregtechceu.gtceu.api.block.OreBlock;
import com.gregtechceu.gtceu.api.data.chemical.material.Material;
import com.gregtechceu.gtceu.api.data.chemical.material.info.MaterialIconType;
import com.gregtechceu.gtceu.api.data.tag.TagPrefix;
import com.gregtechceu.gtceu.common.data.GTBlocks;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import java.util.function.Supplier;
import static com.gregtechceu.gtceu.api.data.tag.TagPrefix.Conditions.hasOreProperty;
import static com.gregtechceu.gtceu.integration.kjs.Validator.*;

public class OreTagPrefixBuilder extends TagPrefixBuilder {
    public transient Supplier<BlockState> stateSupplier;
    public transient Supplier<Material> materialSupplier;
    public transient ResourceLocation baseModelLocation;
    public transient Supplier<BlockBehaviour.Properties> templateProperties;
    public transient boolean doubleDrops = false;
    public transient boolean isSand = false;
    public transient boolean shouldDropAsItem = false;

    public OreTagPrefixBuilder(ResourceLocation id) {
        super(id);
    }

    @Override
    public TagPrefix create(String id) {
        return new TagPrefix(id).defaultTagPath("ores/%s").prefixOnlyTagPath("ores_in_ground/%s").unformattedTagPath("ores").materialIconType(MaterialIconType.ore).unificationEnabled(true).blockConstructor(OreBlock::new).generationCondition(hasOreProperty);
    }

    @Override
    public TagPrefix createObject() {
        validate(this.id, errorIfNull(stateSupplier, "stateSupplier"), onlySetDefault(templateProperties, () -> {
            templateProperties = () -> GTBlocks.copy(stateSupplier.get().getBlock().properties(), BlockBehaviour.Properties.of());
        }), errorIfNull(baseModelLocation, "baseModelLocation"));
        return base.registerOre(stateSupplier, materialSupplier, templateProperties, baseModelLocation, doubleDrops, isSand, shouldDropAsItem);
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public OreTagPrefixBuilder stateSupplier(final Supplier<BlockState> stateSupplier) {
        this.stateSupplier = stateSupplier;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public OreTagPrefixBuilder materialSupplier(final Supplier<Material> materialSupplier) {
        this.materialSupplier = materialSupplier;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public OreTagPrefixBuilder baseModelLocation(final ResourceLocation baseModelLocation) {
        this.baseModelLocation = baseModelLocation;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public OreTagPrefixBuilder templateProperties(final Supplier<BlockBehaviour.Properties> templateProperties) {
        this.templateProperties = templateProperties;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public OreTagPrefixBuilder doubleDrops(final boolean doubleDrops) {
        this.doubleDrops = doubleDrops;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public OreTagPrefixBuilder isSand(final boolean isSand) {
        this.isSand = isSand;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public OreTagPrefixBuilder shouldDropAsItem(final boolean shouldDropAsItem) {
        this.shouldDropAsItem = shouldDropAsItem;
        return this;
    }
}
