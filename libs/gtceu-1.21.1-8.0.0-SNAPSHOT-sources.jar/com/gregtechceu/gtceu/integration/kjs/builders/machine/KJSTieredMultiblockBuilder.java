package com.gregtechceu.gtceu.integration.kjs.builders.machine;

import com.gregtechceu.gtceu.api.blockentity.BlockEntityCreationInfo;
import com.gregtechceu.gtceu.api.machine.MultiblockMachineDefinition;
import com.gregtechceu.gtceu.api.machine.multiblock.MultiblockControllerMachine;
import com.gregtechceu.gtceu.api.registry.registrate.GTRegistrate;
import com.gregtechceu.gtceu.api.registry.registrate.builder.MachineBuilder;
import com.gregtechceu.gtceu.api.registry.registrate.builder.MultiblockMachineBuilder;
import com.gregtechceu.gtceu.api.registry.registrate.entry.MachineEntry;
import com.gregtechceu.gtceu.common.data.machines.GTMachineUtils;
import net.minecraft.resources.ResourceLocation;
import com.google.common.base.Preconditions;
import dev.latvian.mods.kubejs.client.LangKubeEvent;
import dev.latvian.mods.kubejs.generator.KubeAssetGenerator;
import dev.latvian.mods.kubejs.registry.BuilderBase;
import org.jetbrains.annotations.Nullable;
import java.util.Locale;
import static com.gregtechceu.gtceu.api.GTValues.*;

public class KJSTieredMultiblockBuilder extends BuilderBase<MultiblockMachineDefinition> implements IMachineBuilderKJS {
    private final MultiblockMachineBuilder<?>[] builders = new MultiblockMachineBuilder[TIER_COUNT];
    @SuppressWarnings("unchecked")
    private final MachineEntry<MultiblockMachineDefinition>[] machines = new MachineEntry[TIER_COUNT];
    public transient int[] tiers = GTMachineUtils.ELECTRIC_TIERS;
    public transient TieredCreationFunction machine;
    public transient DefinitionFunction definition = (tier, def) -> def.tier(tier);

    public KJSTieredMultiblockBuilder(ResourceLocation id) {
        super(id);
        this.dummyBuilder = true;
    }

    public KJSTieredMultiblockBuilder(ResourceLocation id, TieredCreationFunction machine) {
        super(id);
        this.machine = machine;
        this.dummyBuilder = true;
    }

    @Override
    public void generateMachineModels() {
        for (int tier : this.tiers) {
            generateMachineModel(this.builders[tier], this.machines[tier].value());
        }
    }

    @Override
    public void generateAssets(KubeAssetGenerator generator) {
        for (int tier : this.tiers) {
            MachineEntry<MultiblockMachineDefinition> definition = this.machines[tier];
            if (definition == null) continue;
            final ResourceLocation id = definition.getId();
            generator.itemModel(id, gen -> gen.parent(id.withPrefix("block/machine/")));
        }
    }

    @Override
    public String getTranslationKeyGroup() {
        return "block";
    }

    @Override
    public void generateLang(LangKubeEvent lang) {
        for (int tier : tiers) {
            var def = this.machines[tier];
            if (def != null && def.value().getLangValue() != null) {
                lang.add(def.getId().getNamespace(), def.value().getDescriptionId(), def.value().getLangValue());
            }
        }
    }

    @Override
    @Nullable
    public MultiblockMachineDefinition createObject() {
        Preconditions.checkNotNull(tiers, "Tiers can\'t be null!");
        Preconditions.checkArgument(tiers.length > 0, "tiers must have at least one tier!");
        Preconditions.checkNotNull(machine, "You must set a machine creation function! " + "example: `builder.machine((holder, tier) => new SimpleTieredMachine(holder, tier, t => t * 3200)`");
        Preconditions.checkNotNull(definition, "You must set a definition function! " + "See GTMachines for examples");
        for (final int tier : tiers) {
            String tierName = VN[tier].toLowerCase(Locale.ROOT);
            MultiblockMachineBuilder<?> builder = GTRegistrate.createIgnoringListenerErrors(this.id.getNamespace()).multiblock(String.format("%s_%s", tierName, this.id.getPath()), holder -> machine.create(holder, tier));
            builder.workableTieredHullModel(id.withPrefix("block/machines/")).tier(tier);
            this.definition.apply(tier, builder);
            this.builders[tier] = builder;
            this.machines[tier] = builder.register();
        }
        return null;
    }


    @FunctionalInterface
    public interface TieredCreationFunction {
        MultiblockControllerMachine create(BlockEntityCreationInfo info, int tier);
    }


    @FunctionalInterface
    public interface DefinitionFunction {
        void apply(int tier, MachineBuilder<?, ?, ?> builder);
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public KJSTieredMultiblockBuilder tiers(final int[] tiers) {
        this.tiers = tiers;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public KJSTieredMultiblockBuilder machine(final TieredCreationFunction machine) {
        this.machine = machine;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public KJSTieredMultiblockBuilder definition(final DefinitionFunction definition) {
        this.definition = definition;
        return this;
    }
}
