package com.gregtechceu.gtceu.integration.map.ftbchunks.veins.fluid;

import com.gregtechceu.gtceu.api.data.chemical.ChemicalHelper;
import com.gregtechceu.gtceu.api.item.component.prospector.ProspectorMode;
import com.gregtechceu.gtceu.integration.map.ftbchunks.FTBChunksOptions;
import com.gregtechceu.gtceu.integration.map.layer.builtin.FluidRenderLayer;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.extensions.common.IClientFluidTypeExtensions;
import dev.ftb.mods.ftbchunks.FTBChunks;
import dev.ftb.mods.ftbchunks.api.FTBChunksAPI;
import dev.ftb.mods.ftbchunks.api.client.icon.MapIcon;
import dev.ftb.mods.ftbchunks.api.client.icon.MapType;
import dev.ftb.mods.ftbchunks.client.FTBChunksClientConfig;
import dev.ftb.mods.ftbchunks.client.map.MapDimension;
import dev.ftb.mods.ftbchunks.client.map.WaypointImpl;
import dev.ftb.mods.ftbchunks.client.map.WaypointType;
import dev.ftb.mods.ftblibrary.icon.Color4I;
import dev.ftb.mods.ftblibrary.icon.Icon;
import dev.ftb.mods.ftblibrary.ui.BaseScreen;
import dev.ftb.mods.ftblibrary.ui.input.Key;
import dev.ftb.mods.ftblibrary.ui.input.MouseButton;
import dev.ftb.mods.ftblibrary.util.TooltipList;

public class FluidVeinIcon implements MapIcon {
    public static double MAX_DISTANCE = FTBChunks.TILE_SIZE * FTBChunks.TILE_SIZE;
    private final ChunkPos chunkPos;
    private final Component name;
    private final ProspectorMode.FluidInfo fluidInfo;
    private int size;
    private Icon icon;

    public FluidVeinIcon(ChunkPos chunkPos, Component name, ProspectorMode.FluidInfo fluidInfo) {
        this.chunkPos = chunkPos;
        this.name = name;
        this.fluidInfo = fluidInfo;
        this.size = 1;
    }

    public boolean isEnabled() {
        return FTBChunksOptions.showLayer("bedrock_fluids") && (fluidInfo.left() > 0 || !FTBChunksOptions.hideDepleted());
    }

    public int getColor() {
        var color = IClientFluidTypeExtensions.of(fluidInfo.fluid()).getTintColor();
        var material = ChemicalHelper.getMaterial(fluidInfo.fluid());
        if (material != null) {
            color = material.getMaterialARGB();
        }
        return color;
    }

    @Override
    public double getIconScale(MapType mapType) {
        return mapType.isMinimap() ? FTBChunksClientConfig.MINIMAP_ZOOM.get() : this.size;
    }

    @Override
    public boolean isZoomDependant(MapType mapType) {
        return false;
    }

    @Override
    public boolean isVisible(MapType mapType, double distanceToPlayer, boolean outsideVisibleArea) {
        return !outsideVisibleArea || distanceToPlayer <= MAX_DISTANCE;
    }

    @Override
    public Vec3 getPos(float v) {
        return getMiddleBlock().getCenter();
    }

    public BlockPos getMiddleBlock() {
        return chunkPos.getBlockAt(7, 70, 7);
    }

    @Override
    public boolean onMousePressed(BaseScreen baseScreen, MouseButton mouseButton) {
        if (!isEnabled()) {
            return false;
        }
        MapDimension.getCurrent().ifPresent(mapDimension -> FTBChunksAPI.clientApi().getWaypointManager(mapDimension.dimension).ifPresent(waypointManager -> {
            var pos = getMiddleBlock();
            var waypoint = new WaypointImpl(WaypointType.DEFAULT, mapDimension, pos);
            if (!waypointManager.getAllWaypoints().contains(waypoint)) {
                waypointManager.addWaypointAt(pos, this.getName().getString()).setColor(getColor()).setHidden(false);
                baseScreen.refreshWidgets();
            }
        }));
        return true;
    }

    @Override
    public void addTooltip(TooltipList list) {
        FluidRenderLayer.getTooltip(this.name, this.fluidInfo).forEach(list::add);
    }

    @Override
    public boolean onKeyPressed(BaseScreen baseScreen, Key key) {
        return false;
    }

    public Icon getIcon(int alpha, boolean mouseOver) {
        var color = getColor();
        var fluidIcon = Icon.getIcon(IClientFluidTypeExtensions.of(this.fluidInfo.fluid()).getStillTexture()).withColor(Color4I.rgba(color).withAlpha(alpha));
        if (mouseOver) {
            fluidIcon = fluidIcon.withBorder(Color4I.rgba(color), false);
        }
        return fluidIcon;
    }

    @Override
    public void draw(MapType mapType, GuiGraphics graphics, int x, int y, int w, int h, boolean outsideVisibleArea, int iconAlpha) {
        if (!mapType.isMinimap() || !isEnabled()) {
            return;
        }
        if (this.icon == null) {
            this.icon = getIcon(200, false);
        }
        this.icon.draw(graphics, x, y, w, h);
    }

    public ChunkPos getChunkPos() {
        return this.chunkPos;
    }

    public Component getName() {
        return this.name;
    }

    public ProspectorMode.FluidInfo getFluidInfo() {
        return this.fluidInfo;
    }

    public void setSize(final int size) {
        this.size = size;
    }
}
