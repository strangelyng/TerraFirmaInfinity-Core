package com.gregtechceu.gtceu.client.bloom;

import com.gregtechceu.gtceu.GTCEu;
import net.minecraft.client.Minecraft;
import net.minecraft.core.SectionPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.RenderFrameEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.level.ChunkEvent;
import net.neoforged.neoforge.event.level.LevelEvent;

@EventBusSubscriber(modid = GTCEu.MOD_ID, value = Dist.CLIENT)
public final class BloomEventListeners {
    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        if (!BloomRenderer.usesChunkPassBackend()) {
            NeoForge.EVENT_BUS.register(BloomRenderer.SafeMode.class);
        }
    }

    @SubscribeEvent
    public static void afterParticlesRendered(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        BloomRenderer.renderBloom(event.getCamera(), event.getPoseStack(), event.getFrustum(), event.getModelViewMatrix(), event.getProjectionMatrix(), event.getPartialTick().getGameTimeDeltaPartialTick(false), event.getLevelRenderer(), Minecraft.getInstance().getProfiler());
    }

    @SubscribeEvent
    public static void onRenderTick(RenderFrameEvent.Pre event) {
        if (Minecraft.getInstance().level == null) return;
        if (!BloomShaderManager.isBloomActive()) return;
        BloomShaderManager.BLOOM_TARGET.clear(Minecraft.ON_OSX);
        Minecraft.getInstance().getMainRenderTarget().bindWrite(false);
    }

    @SubscribeEvent
    public static void onLevelUnload(LevelEvent.Unload event) {
        BloomHandler.invalidateLevelData(event.getLevel());
        if (!BloomRenderer.usesChunkPassBackend()) {
            BloomRenderer.SafeMode.invalidateLevelData();
        }
    }

    @SubscribeEvent
    public static void onChunkUnload(ChunkEvent.Unload event) {
        if (!BloomShaderManager.isBloomActive()) return;
        ChunkAccess chunk = event.getChunk();
        LevelAccessor level = chunk.getLevel();
        if (level == null) return;
        if (BloomRenderer.usesChunkPassBackend()) return;
        ChunkPos chunkPos = chunk.getPos();
        int minSection = level.getMinSection();
        int maxSection = level.getMaxSection();
        for (int y = minSection; y < maxSection; y++) {
            BloomRenderer.SafeMode.invalidateSectionData(SectionPos.of(chunkPos.x, y, chunkPos.z));
        }
    }

    private BloomEventListeners() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}
