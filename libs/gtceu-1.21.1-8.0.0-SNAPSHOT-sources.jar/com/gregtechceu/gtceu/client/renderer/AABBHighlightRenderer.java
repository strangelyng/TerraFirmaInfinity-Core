package com.gregtechceu.gtceu.client.renderer;

import net.minecraft.client.Camera;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.util.FastColor;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import lombok.experimental.Tolerate;
import java.util.List;

@OnlyIn(Dist.CLIENT)
public class AABBHighlightRenderer {
    public static final AABBHighlightRenderer INSTANCE = new AABBHighlightRenderer();
    private final List<AABBHighlight> highlights = new ObjectArrayList<>();

    public void tick(PoseStack stack, MultiBufferSource.BufferSource bufferSource, Camera camera) {
        if (GameRenderer.getPositionColorShader() == null || !camera.isInitialized()) return;
        Vec3 offset = camera.getPosition().reverse();
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        RenderSystem.disableCull();
        stack.pushPose();
        stack.translate(offset.x, offset.y, offset.z);
        VertexConsumer buffer = bufferSource.getBuffer(RenderType.lines());
        long time = System.currentTimeMillis();
        highlights.forEach(h -> h.render(buffer, stack, time));
        stack.popPose();
        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
    }

    public void addHighlight(AABBHighlight highlight) {
        highlights.add(highlight);
    }


    public record AABBHighlight(AABB aabb, int colorARGB, long startMillis, long durationMillis, long phaseMillis, double thickness) {
        public void render(VertexConsumer buffer, PoseStack poseStack, long currentTimeMillis) {
            if (currentTimeMillis - startMillis >= durationMillis) {
                this.remove();
                return;
            }
            if (currentTimeMillis < startMillis) return;
            if ((currentTimeMillis - startMillis) / phaseMillis % 2 == 1) return;
            LevelRenderer.renderLineBox(poseStack, buffer, aabb, FastColor.ARGB32.red(colorARGB), FastColor.ARGB32.green(colorARGB), FastColor.ARGB32.blue(colorARGB), FastColor.ARGB32.alpha(colorARGB));
        }

        public void remove() {
            // FIXME CME inbound here!
            AABBHighlightRenderer.INSTANCE.highlights.remove(this);
        }
    }

    public static AABBHighlightBuilder builder() {
        return new AABBHighlightBuilder();
    }


    public static class AABBHighlightBuilder {
        private AABB aabb = null;
        private int colorARGB = -1;
        private long startMillis = -1;
        private long durationMillis = 10000;
        private long phaseMillis = 300;
        private double thickness = 0.01;

        @Tolerate
        public AABBHighlightBuilder aabb(BlockPos pos) {
            this.aabb = new AABB(pos);
            return this;
        }

        public AABBHighlightBuilder colorARGB(int alpha, int red, int green, int blue) {
            this.colorARGB = FastColor.ARGB32.color(alpha, red, green, blue);
            return this;
        }

        public AABBHighlight build() {
            if (aabb == null) {
                throw new IllegalArgumentException("AABB can\'t be null in AABBHighlightBuilder");
            }
            if (startMillis == -1) {
                startMillis = System.currentTimeMillis();
            }
            return new AABBHighlight(aabb, colorARGB, startMillis, durationMillis, phaseMillis, thickness);
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public AABBHighlightRenderer.AABBHighlightBuilder aabb(final AABB aabb) {
            this.aabb = aabb;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public AABBHighlightRenderer.AABBHighlightBuilder colorARGB(final int colorARGB) {
            this.colorARGB = colorARGB;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public AABBHighlightRenderer.AABBHighlightBuilder startMillis(final long startMillis) {
            this.startMillis = startMillis;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public AABBHighlightRenderer.AABBHighlightBuilder durationMillis(final long durationMillis) {
            this.durationMillis = durationMillis;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public AABBHighlightRenderer.AABBHighlightBuilder phaseMillis(final long phaseMillis) {
            this.phaseMillis = phaseMillis;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public AABBHighlightRenderer.AABBHighlightBuilder thickness(final double thickness) {
            this.thickness = thickness;
            return this;
        }
    }

    public AABBHighlightRenderer() {
    }
}
