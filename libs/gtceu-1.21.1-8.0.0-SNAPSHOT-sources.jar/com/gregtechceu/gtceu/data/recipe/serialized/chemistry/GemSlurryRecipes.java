package com.gregtechceu.gtceu.data.recipe.serialized.chemistry;

import net.minecraft.data.recipes.RecipeOutput;

import static com.gregtechceu.gtceu.api.GTValues.*;
import static com.gregtechceu.gtceu.api.data.chemical.material.info.MaterialFlags.*;
import static com.gregtechceu.gtceu.api.data.tag.TagPrefix.*;
import static com.gregtechceu.gtceu.common.data.GTMaterials.*;
import static com.gregtechceu.gtceu.common.data.GTRecipeTypes.CENTRIFUGE_RECIPES;
import static com.gregtechceu.gtceu.common.data.GTRecipeTypes.MIXER_RECIPES;

public class GemSlurryRecipes {

    public static void init(RecipeOutput provider) {
        // Ruby
        MIXER_RECIPES.recipeBuilder("ruby_slurry_from_crushed_ruby").duration(280).EUt(VA[EV])
                .inputItems(crushed, Ruby, 2)
                .inputFluids(AquaRegia.getFluid(3000))
                .outputFluids(RubySlurry.getFluid(3000))
                .save(provider);

        MIXER_RECIPES.recipeBuilder("ruby_slurry_from_washed_ruby").duration(280).EUt(VA[EV])
                .inputItems(crushedPurified, Ruby, 2)
                .inputFluids(AquaRegia.getFluid(3000))
                .outputFluids(RubySlurry.getFluid(3000))
                .save(provider);

        CENTRIFUGE_RECIPES.recipeBuilder("ruby_slurry_centrifuging").duration(320).EUt(VA[HV])
                .inputFluids(RubySlurry.getFluid(3000))
                .outputItems(dust, Aluminium, 2)
                .outputItems(dust, Chromium)
                .chancedOutput(dust, Titanium, 200)
                .chancedOutput(dust, Iron, 200)
                .chancedOutput(dust, Vanadium, 200)
                .outputFluids(DilutedHydrochloricAcid.getFluid(2000))
                .save(provider);

        // Sapphire
        MIXER_RECIPES.recipeBuilder("sapphire_slurry_from_crushed_sapphire").duration(280).EUt(VA[EV])
                .inputItems(crushed, Sapphire, 2)
                .inputFluids(AquaRegia.getFluid(3000))
                .outputFluids(SapphireSlurry.getFluid(3000))
                .save(provider);

        MIXER_RECIPES.recipeBuilder("sapphire_slurry_from_washed_sapphire").duration(280).EUt(VA[EV])
                .inputItems(crushedPurified, Sapphire, 2)
                .inputFluids(AquaRegia.getFluid(3000))
                .outputFluids(SapphireSlurry.getFluid(3000))
                .save(provider);

        CENTRIFUGE_RECIPES.recipeBuilder("sapphire_slurry_centrifuging").duration(320).EUt(VA[HV])
                .inputFluids(SapphireSlurry.getFluid(3000))
                .outputItems(dust, Aluminium, 2)
                .chancedOutput(dust, Titanium, 200)
                .chancedOutput(dust, Iron, 200)
                .chancedOutput(dust, Vanadium, 200)
                .outputFluids(DilutedHydrochloricAcid.getFluid(2000))
                .save(provider);

        // Green Sapphire
        MIXER_RECIPES.recipeBuilder("green_sapphire_slurry_from_crushed_green_sapphire").duration(280).EUt(VA[EV])
                .inputItems(crushed, GreenSapphire, 2)
                .inputFluids(AquaRegia.getFluid(3000))
                .outputFluids(GreenSapphireSlurry.getFluid(3000))
                .save(provider);

        MIXER_RECIPES.recipeBuilder("green_sapphire_slurry_from_washed_green_sapphire").duration(280).EUt(VA[EV])
                .inputItems(crushedPurified, GreenSapphire, 2)
                .inputFluids(AquaRegia.getFluid(3000))
                .outputFluids(GreenSapphireSlurry.getFluid(3000))
                .save(provider);

        CENTRIFUGE_RECIPES.recipeBuilder("green_sapphire_slurry_centrifuging").duration(320).EUt(VA[HV])
                .inputFluids(GreenSapphireSlurry.getFluid(3000))
                .outputItems(dust, Aluminium, 2)
                .chancedOutput(dust, Beryllium, 200)
                .chancedOutput(dust, Titanium, 200)
                .chancedOutput(dust, Iron, 200)
                .chancedOutput(dust, Vanadium, 200)
                .outputFluids(DilutedHydrochloricAcid.getFluid(2000))
                .save(provider);
    }
}
